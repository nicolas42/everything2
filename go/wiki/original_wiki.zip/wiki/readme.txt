https://github.com/benawad/gowiki

# gowiki
Super basic Go website with plain text files as storage.

Start it by running `go run wiki.go` then go to [localhost:8080](http://localhost:8080) in your browser.

Made by following along with this tutorial: [https://golang.org/doc/articles/wiki/](https://golang.org/doc/articles/wiki/)
